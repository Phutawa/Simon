// ============================================================
// The Simon Game — game.js
// Implements the classic Simon memory game using jQuery.
// ============================================================

// -------------------------------------------------------
// Step 1-2: Initialization & Pattern Generation
// -------------------------------------------------------

// The four possible button colours
var buttonColours = ["red", "blue", "green", "yellow"];

// Stores the sequence the game generates each round
var gamePattern = [];

// Stores the sequence the user clicks during the current round
var userClickedPattern = [];

// -------------------------------------------------------
// Step 7 (partial): Game-state variables
// -------------------------------------------------------

// Whether the game has started (prevents repeat starts)
var started = false;

// Current level (incremented before each new round)
var level = 0;

// -------------------------------------------------------
// Step 7: Start the game on the first keypress
// -------------------------------------------------------
$(document).keypress(function () {
  if (!started) {
    // Show "Level 0" momentarily, then generate the first colour
    $("#level-title").text("Level 0");
    nextSequence();
    started = true;
  }
});

// -------------------------------------------------------
// Step 1-2 (continued) & Step 3: Generate the next colour
//   in the sequence; animate and play its sound.
// Step 7 (continued): Increment level & update heading.
// -------------------------------------------------------
function nextSequence() {

  // Reset the user's clicks for the new round
  userClickedPattern = [];

  // Increase the level and display it
  level++;
  $("#level-title").text("Level " + level);

  // Pick a random index (0-3) and get the colour
  var randomNumber = Math.floor(Math.random() * 4);
  var randomChosenColour = buttonColours[randomNumber];

  // Append the new colour to the game pattern
  gamePattern.push(randomChosenColour);

  // Step 3 — Flash the button so the player can clearly see which colour was chosen
  $("#" + randomChosenColour).addClass("pressed");
  setTimeout(function () {
    $("#" + randomChosenColour).removeClass("pressed");
  }, 500);

  playSound(randomChosenColour);
}

// -------------------------------------------------------
// Step 4-6: Detect user clicks, record choice,
//   play sound, animate, and check the answer.
// -------------------------------------------------------
$(".btn").click(function () {

  // Get the id of the clicked button (e.g. "green")
  var userChosenColour = $(this).attr("id");

  // Push it into the user's pattern array
  userClickedPattern.push(userChosenColour);

  // Play the corresponding sound
  playSound(userChosenColour);

  // Show a brief "pressed" animation
  animatePress(userChosenColour);

  // Step 8 — Check the answer after every click
  checkAnswer(userClickedPattern.length - 1);
});

// -------------------------------------------------------
// Step 6: Play a sound from the sounds/ folder
// -------------------------------------------------------
function playSound(name) {
  var audio = new Audio("sounds/" + name + ".mp3");
  audio.play();
}

// -------------------------------------------------------
// Step 6: Animate the "pressed" effect on a button
// -------------------------------------------------------
function animatePress(currentColour) {
  // Add the CSS class that creates the visual feedback
  $("#" + currentColour).addClass("pressed");

  // Remove it after 100 ms so it's just a brief flash
  setTimeout(function () {
    $("#" + currentColour).removeClass("pressed");
  }, 100);
}

// -------------------------------------------------------
// Step 8: Check the user's answer against the game pattern
// -------------------------------------------------------
function checkAnswer(currentLevel) {

  // Compare the latest user click with the corresponding game colour
  if (gamePattern[currentLevel] === userClickedPattern[currentLevel]) {

    // The user has completed the entire current sequence correctly
    if (userClickedPattern.length === gamePattern.length) {

      // Wait 1 second, then generate the next colour in the sequence
      setTimeout(function () {
        nextSequence();
      }, 1000);
    }
    // If the sequence isn't finished yet, do nothing — wait for more clicks

  } else {

    // -------------------------------------------------------
    // Step 9-10: Wrong answer — Game Over & Restart
    // -------------------------------------------------------

    // Play the "wrong" buzzer sound
    playSound("wrong");

    // Flash the page red for 200 ms
    $("body").addClass("game-over");
    setTimeout(function () {
      $("body").removeClass("game-over");
    }, 200);

    // Update the heading with the restart message
    $("#level-title").text("Game Over, Press Any Key to Restart");

    // Reset all game state so a new keypress starts fresh
    startOver();
  }
}

// -------------------------------------------------------
// Step 10: Reset game variables so the player can retry
// -------------------------------------------------------
function startOver() {
  level = 0;
  gamePattern = [];
  started = false;
}
